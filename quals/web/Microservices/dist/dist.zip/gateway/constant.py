routes = {"admin_page": "http://admin_page", "home_page": "http://home_page"}
excluded_headers = [
    "content-encoding",
    "content-length",
    "transfer-encoding",
    "connection",
]
